export function getRandomName() {
  const names = [
    "Anjali",
    "Pratima",
    "Sadik",
    "Rohit",
    "Amit",
    "Pranay",
    "Anujesh",
    "Ashish",
  ];
  // return names[Math.round(Math.random() * names.length)];
  return "Prabhat";
}
