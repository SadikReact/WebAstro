export const AstroSkills = [
  {
    id: "1",
    value: "Face Reading",
  },
  {
    id: "2",
    value: "Kp",
  },
  {
    id: "3",
    value: "Life Coach",
  },
  {
    id: "4",
    value: "Nadi",
  },
  {
    id: "5",
    value: "Numerology",
  },
  {
    id: "6",
    value: "Palmistry",
  },
  {
    id: "7",
    value: "Prashana",
  },

  {
    id: "8",
    value: "Psychic",
  },
  {
    id: "9",
    value: "Tarot",
  },
  {
    id: "10",
    value: "Vedic",
  },
];

export const Specialisation = [
  {
    id: "1",
    value: "Face Reading",
  },
  {
    id: "2",
    value: "Kp",
  },
  {
    id: "3",
    value: "Life Coach",
  },
  {
    id: "4",
    value: "Nadi",
  },
  {
    id: "5",
    value: "Numerology",
  },
  {
    id: "6",
    value: "Palmistry",
  },
  {
    id: "7",
    value: "Prashana",
  },

  {
    id: "8",
    value: "Psychic",
  },
  {
    id: "9",
    value: "Tarot",
  },
  {
    id: "10",
    value: "Vedic",
  },
];
export const Language = [
  {
    id: "1",
    value: "English",
  },
  {
    id: "2",
    value: "Bengali",
  },
  {
    id: "3",
    value: "Gujarati",
  },
  {
    id: "4",
    value: "Hindi",
  },
  {
    id: "5",
    value: "Kannada",
  },
  {
    id: "6",
    value: "Marathi",
  },
  {
    id: "7",
    value: "Punjabi",
  },
  {
    id: "8",
    value: "Tamil",
  },
  {
    id: "9",
    value: "Telugu",
  },
];

export const AstroStatus = [
  {
    id: "1",
    value: "Online",
  },
  {
    id: "2",
    value: "Offline",
  },
];
